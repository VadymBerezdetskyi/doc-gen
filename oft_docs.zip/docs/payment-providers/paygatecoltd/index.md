
# PayGate Co. Ltd. 
![paygatecoltd](https://static.openfintech.io/payment_providers/paygatecoltd/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `paygatecoltd` 
 
**Vendor:** `paygatecoltd` 
 
**Name:** 
 
:	[EN] PayGate Co. Ltd. 
 

## Images 

### Logo 
 
![paygatecoltd](https://static.openfintech.io/payment_providers/paygatecoltd/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/paygatecoltd/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![paygatecoltd](https://static.openfintech.io/payment_providers/paygatecoltd/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/paygatecoltd/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"paygatecoltd",
  "description":null,
  "vendor":"paygatecoltd",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"paygatecoltd"
  },
  "name":{
    "en":"PayGate Co. Ltd."
  }
}
```  
