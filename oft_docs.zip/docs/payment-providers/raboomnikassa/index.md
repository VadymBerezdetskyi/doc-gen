
# Rabo OmniKassa 
![raboomnikassa](https://static.openfintech.io/payment_providers/raboomnikassa/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `raboomnikassa` 
 
**Vendor:** `raboomnikassa` 
 
**Name:** 
 
:	[EN] Rabo OmniKassa 
 

## Images 

### Logo 
 
![raboomnikassa](https://static.openfintech.io/payment_providers/raboomnikassa/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/raboomnikassa/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![raboomnikassa](https://static.openfintech.io/payment_providers/raboomnikassa/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/raboomnikassa/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"raboomnikassa",
  "description":null,
  "vendor":"raboomnikassa",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"raboomnikassa"
  },
  "name":{
    "en":"Rabo OmniKassa"
  }
}
```  
