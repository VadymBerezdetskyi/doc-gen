
# omba 
![ombaug](https://static.openfintech.io/payment_providers/ombaug/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `ombaug` 
 
**Vendor:** `ombaug` 
 
**Name:** 
 
:	[EN] omba 
 

## Images 

### Logo 
 
![ombaug](https://static.openfintech.io/payment_providers/ombaug/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/ombaug/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![ombaug](https://static.openfintech.io/payment_providers/ombaug/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/ombaug/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"ombaug",
  "description":null,
  "vendor":"ombaug",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"ombaug"
  },
  "name":{
    "en":"omba"
  }
}
```  
