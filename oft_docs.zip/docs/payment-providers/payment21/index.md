
# Payment21 
![payment21](https://static.openfintech.io/payment_providers/payment21/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `payment21` 
 
**Vendor:** `payment21` 
 
**Name:** 
 
:	[EN] Payment21 
 

## Images 

### Logo 
 
![payment21](https://static.openfintech.io/payment_providers/payment21/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/payment21/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![payment21](https://static.openfintech.io/payment_providers/payment21/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/payment21/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"payment21",
  "description":null,
  "vendor":"payment21",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"payment21"
  },
  "name":{
    "en":"Payment21"
  }
}
```  
