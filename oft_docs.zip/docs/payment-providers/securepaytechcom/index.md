
# SecurePayTech.com 
![securepaytechcom](https://static.openfintech.io/payment_providers/securepaytechcom/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `securepaytechcom` 
 
**Vendor:** `securepaytechcom` 
 
**Name:** 
 
:	[EN] SecurePayTech.com 
 

## Images 

### Logo 
 
![securepaytechcom](https://static.openfintech.io/payment_providers/securepaytechcom/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/securepaytechcom/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![securepaytechcom](https://static.openfintech.io/payment_providers/securepaytechcom/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/securepaytechcom/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"securepaytechcom",
  "description":null,
  "vendor":"securepaytechcom",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"securepaytechcom"
  },
  "name":{
    "en":"SecurePayTech.com"
  }
}
```  
