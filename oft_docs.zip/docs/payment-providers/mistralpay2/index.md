
# MistralPay 
![mistralpay2](https://static.openfintech.io/payment_providers/mistralpay2/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `mistralpay2` 
 
**Vendor:** `mistralpay2` 
 
**Name:** 
 
:	[EN] MistralPay 
 

## Images 

### Logo 
 
![mistralpay2](https://static.openfintech.io/payment_providers/mistralpay2/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/mistralpay2/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![mistralpay2](https://static.openfintech.io/payment_providers/mistralpay2/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/mistralpay2/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"mistralpay2",
  "description":null,
  "vendor":"mistralpay2",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"mistralpay2"
  },
  "name":{
    "en":"MistralPay"
  }
}
```  
