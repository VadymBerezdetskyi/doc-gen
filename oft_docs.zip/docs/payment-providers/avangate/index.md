
# Avangate Inc. 
![avangate](https://static.openfintech.io/payment_providers/avangate/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `avangate` 
 
**Vendor:** `avangate` 
 
**Name:** 
 
:	[EN] Avangate Inc. 
 

## Images 

### Logo 
 
![avangate](https://static.openfintech.io/payment_providers/avangate/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/avangate/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![avangate](https://static.openfintech.io/payment_providers/avangate/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/avangate/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"avangate",
  "description":null,
  "vendor":"avangate",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"avangate"
  },
  "name":{
    "en":"Avangate Inc."
  }
}
```  
