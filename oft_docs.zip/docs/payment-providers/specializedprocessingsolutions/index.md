
# Specialized Processing Solutions 
![specializedprocessingsolutions](https://static.openfintech.io/payment_providers/specializedprocessingsolutions/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `specializedprocessingsolutions` 
 
**Vendor:** `specializedprocessingsolutions` 
 
**Name:** 
 
:	[EN] Specialized Processing Solutions 
 

## Images 

### Logo 
 
![specializedprocessingsolutions](https://static.openfintech.io/payment_providers/specializedprocessingsolutions/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/specializedprocessingsolutions/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![specializedprocessingsolutions](https://static.openfintech.io/payment_providers/specializedprocessingsolutions/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/specializedprocessingsolutions/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"specializedprocessingsolutions",
  "description":null,
  "vendor":"specializedprocessingsolutions",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"specializedprocessingsolutions"
  },
  "name":{
    "en":"Specialized Processing Solutions"
  }
}
```  
