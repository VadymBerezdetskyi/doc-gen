
# Ypsilon Payment Solutions 
![ypsilonpaymentsolutions](https://static.openfintech.io/payment_providers/ypsilonpaymentsolutions/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `ypsilonpaymentsolutions` 
 
**Vendor:** `ypsilonpaymentsolutions` 
 
**Name:** 
 
:	[EN] Ypsilon Payment Solutions 
 

## Images 

### Logo 
 
![ypsilonpaymentsolutions](https://static.openfintech.io/payment_providers/ypsilonpaymentsolutions/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/ypsilonpaymentsolutions/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![ypsilonpaymentsolutions](https://static.openfintech.io/payment_providers/ypsilonpaymentsolutions/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/ypsilonpaymentsolutions/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"ypsilonpaymentsolutions",
  "description":null,
  "vendor":"ypsilonpaymentsolutions",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"ypsilonpaymentsolutions"
  },
  "name":{
    "en":"Ypsilon Payment Solutions"
  }
}
```  
