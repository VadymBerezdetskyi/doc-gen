
# ILIXIUM 
![trustpayglobal](https://static.openfintech.io/payment_providers/trustpayglobal/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `trustpayglobal` 
 
**Vendor:** `trustpayglobal` 
 
**Name:** 
 
:	[EN] ILIXIUM 
 

## Images 

### Logo 
 
![trustpayglobal](https://static.openfintech.io/payment_providers/trustpayglobal/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/trustpayglobal/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![trustpayglobal](https://static.openfintech.io/payment_providers/trustpayglobal/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/trustpayglobal/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"trustpayglobal",
  "description":null,
  "vendor":"trustpayglobal",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"trustpayglobal"
  },
  "name":{
    "en":"ILIXIUM"
  }
}
```  
