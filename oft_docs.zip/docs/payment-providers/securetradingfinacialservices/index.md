
# Secure Trading Financial Services 
![securetradingfinacialservices](https://static.openfintech.io/payment_providers/securetradingfinacialservices/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `securetradingfinacialservices` 
 
**Vendor:** `securetradingfinacialservices` 
 
**Name:** 
 
:	[EN] Secure Trading Financial Services 
 

## Images 

### Logo 
 
![securetradingfinacialservices](https://static.openfintech.io/payment_providers/securetradingfinacialservices/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/securetradingfinacialservices/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![securetradingfinacialservices](https://static.openfintech.io/payment_providers/securetradingfinacialservices/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/securetradingfinacialservices/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"securetradingfinacialservices",
  "description":null,
  "vendor":"securetradingfinacialservices",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"securetradingfinacialservices"
  },
  "name":{
    "en":"Secure Trading Financial Services"
  }
}
```  
