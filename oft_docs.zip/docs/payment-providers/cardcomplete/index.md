
# card complete 
![cardcomplete](https://static.openfintech.io/payment_providers/cardcomplete/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `cardcomplete` 
 
**Vendor:** `cardcomplete` 
 
**Name:** 
 
:	[EN] card complete 
 

## Images 

### Logo 
 
![cardcomplete](https://static.openfintech.io/payment_providers/cardcomplete/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/cardcomplete/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![cardcomplete](https://static.openfintech.io/payment_providers/cardcomplete/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/cardcomplete/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"cardcomplete",
  "description":null,
  "vendor":"cardcomplete",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"cardcomplete"
  },
  "name":{
    "en":"card complete"
  }
}
```  
