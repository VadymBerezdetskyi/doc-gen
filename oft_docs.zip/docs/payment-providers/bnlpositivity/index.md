
# BNL POSitivity 
![bnlpositivity](https://static.openfintech.io/payment_providers/bnlpositivity/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `bnlpositivity` 
 
**Vendor:** `bnlpositivity` 
 
**Name:** 
 
:	[EN] BNL POSitivity 
 

## Images 

### Logo 
 
![bnlpositivity](https://static.openfintech.io/payment_providers/bnlpositivity/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/bnlpositivity/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![bnlpositivity](https://static.openfintech.io/payment_providers/bnlpositivity/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/bnlpositivity/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"bnlpositivity",
  "description":null,
  "vendor":"bnlpositivity",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"bnlpositivity"
  },
  "name":{
    "en":"BNL POSitivity"
  }
}
```  
