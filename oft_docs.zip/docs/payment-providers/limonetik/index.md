
# Limonetik 
![limonetik](https://static.openfintech.io/payment_providers/limonetik/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `limonetik` 
 
**Vendor:** `limonetik` 
 
**Name:** 
 
:	[EN] Limonetik 
 

## Images 

### Logo 
 
![limonetik](https://static.openfintech.io/payment_providers/limonetik/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/limonetik/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![limonetik](https://static.openfintech.io/payment_providers/limonetik/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/limonetik/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"limonetik",
  "description":null,
  "vendor":"limonetik",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"limonetik"
  },
  "name":{
    "en":"Limonetik"
  }
}
```  
