
# Cardstream 
![cardstreamlimited](https://static.openfintech.io/payment_providers/cardstreamlimited/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `cardstreamlimited` 
 
**Vendor:** `cardstreamlimited` 
 
**Name:** 
 
:	[EN] Cardstream 
 

## Images 

### Logo 
 
![cardstreamlimited](https://static.openfintech.io/payment_providers/cardstreamlimited/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/cardstreamlimited/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![cardstreamlimited](https://static.openfintech.io/payment_providers/cardstreamlimited/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/cardstreamlimited/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"cardstreamlimited",
  "description":null,
  "vendor":"cardstreamlimited",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"cardstreamlimited"
  },
  "name":{
    "en":"Cardstream"
  }
}
```  
