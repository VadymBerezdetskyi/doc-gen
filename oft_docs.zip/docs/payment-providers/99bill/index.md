
# 99bill.com 
![99bill](https://static.openfintech.io/payment_providers/99bill/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `99bill` 
 
**Vendor:** `99bill` 
 
**Name:** 
 
:	[EN] 99bill.com 
 
**Categories:**`distributing` 
 
 
**Countries:** 
 
:	![CL](https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.3.0/flags/4x3/cl.svg#w24)  

## Images 

### Logo 
 
![99bill](https://static.openfintech.io/payment_providers/99bill/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/99bill/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![99bill](https://static.openfintech.io/payment_providers/99bill/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/99bill/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"99bill",
  "description":null,
  "vendor":"99bill",
  "categories":[
    "distributing"
  ],
  "countries":[
    "CL"
  ],
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"99bill"
  },
  "name":{
    "en":"99bill.com"
  }
}
```  
