
# PayAnyWay.com 
![payanyway](https://static.openfintech.io/payment_providers/payanyway/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `payanyway` 
 
**Vendor:** `payanyway` 
 
**Name:** 
 
:	[EN] PayAnyWay.com 
 

## Images 

### Logo 
 
![payanyway](https://static.openfintech.io/payment_providers/payanyway/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/payanyway/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![payanyway](https://static.openfintech.io/payment_providers/payanyway/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/payanyway/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"payanyway",
  "description":null,
  "vendor":"payanyway",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"payanyway"
  },
  "name":{
    "en":"PayAnyWay.com"
  }
}
```  
