
# AnyCash 
![anycash](https://static.openfintech.io/payment_providers/anycash/logo.svg?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `anycash` 
 
**Vendor:** `anycash` 
 
**Name:** 
 
:	[EN] AnyCash 
 

## Images 

### Logo 
 
![anycash](https://static.openfintech.io/payment_providers/anycash/logo.svg?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/anycash/logo.svg?w=400&c=v0.59.26#w100
```  

### Icon 
 
![anycash](https://static.openfintech.io/payment_providers/anycash/icon.svg?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/anycash/icon.svg?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"anycash",
  "description":null,
  "vendor":"anycash",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":null,
  "name":{
    "en":"AnyCash"
  }
}
```  
