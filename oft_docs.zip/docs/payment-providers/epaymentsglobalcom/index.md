
# ePaymentsglobal.com 
![epaymentsglobalcom](https://static.openfintech.io/payment_providers/epaymentsglobalcom/logo.svg?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `epaymentsglobalcom` 
 
**Vendor:** `epaymentsglobalcom` 
 
**Name:** 
 
:	[EN] ePaymentsglobal.com 
 

## Images 

### Logo 
 
![epaymentsglobalcom](https://static.openfintech.io/payment_providers/epaymentsglobalcom/logo.svg?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/epaymentsglobalcom/logo.svg?w=400&c=v0.59.26#w100
```  

### Icon 
 
![epaymentsglobalcom](https://static.openfintech.io/payment_providers/epaymentsglobalcom/icon.svg?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/epaymentsglobalcom/icon.svg?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"epaymentsglobalcom",
  "description":null,
  "vendor":"epaymentsglobalcom",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"epaymentsglobalcom"
  },
  "name":{
    "en":"ePaymentsglobal.com"
  }
}
```  
