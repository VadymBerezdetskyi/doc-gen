
# Zombaio 
![zombaio](https://static.openfintech.io/payment_providers/zombaio/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `zombaio` 
 
**Vendor:** `zombaio` 
 
**Name:** 
 
:	[EN] Zombaio 
 

## Images 

### Logo 
 
![zombaio](https://static.openfintech.io/payment_providers/zombaio/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/zombaio/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![zombaio](https://static.openfintech.io/payment_providers/zombaio/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/zombaio/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"zombaio",
  "description":null,
  "vendor":"zombaio",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"zombaio"
  },
  "name":{
    "en":"Zombaio"
  }
}
```  
