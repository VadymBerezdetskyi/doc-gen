
# Moneta.RU 
![monetaru](https://static.openfintech.io/payment_providers/monetaru/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `monetaru` 
 
**Vendor:** `monetaru` 
 
**Name:** 
 
:	[EN] Moneta.RU 
 

## Images 

### Logo 
 
![monetaru](https://static.openfintech.io/payment_providers/monetaru/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/monetaru/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![monetaru](https://static.openfintech.io/payment_providers/monetaru/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/monetaru/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"monetaru",
  "description":null,
  "vendor":"monetaru",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"monetaru"
  },
  "name":{
    "en":"Moneta.RU"
  }
}
```  
