
# 123Send 
![123send](https://static.openfintech.io/payment_providers/123send/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `123send` 
 
**Vendor:** `123send` 
 
**Name:** 
 
:	[EN] 123Send 
 
 
**Countries:** 
 
:	![AE](https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.3.0/flags/4x3/ae.svg#w24)  

## Images 

### Logo 
 
![123send](https://static.openfintech.io/payment_providers/123send/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/123send/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![123send](https://static.openfintech.io/payment_providers/123send/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/123send/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"123send",
  "description":null,
  "vendor":"123send",
  "categories":null,
  "countries":[
    "AE"
  ],
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"123send"
  },
  "name":{
    "en":"123Send"
  }
}
```  
