
# YourPay 
![yourpay](https://static.openfintech.io/payment_providers/yourpay/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `yourpay` 
 
**Vendor:** `yourpay` 
 
**Name:** 
 
:	[EN] YourPay 
 

## Images 

### Logo 
 
![yourpay](https://static.openfintech.io/payment_providers/yourpay/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/yourpay/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![yourpay](https://static.openfintech.io/payment_providers/yourpay/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/yourpay/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"yourpay",
  "description":null,
  "vendor":"yourpay",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"yourpay"
  },
  "name":{
    "en":"YourPay"
  }
}
```  
