
# SecurePay.com 
![securepaycom](https://static.openfintech.io/payment_providers/securepaycom/logo.svg?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `securepaycom` 
 
**Vendor:** `securepaycom` 
 
**Name:** 
 
:	[EN] SecurePay.com 
 

## Images 

### Logo 
 
![securepaycom](https://static.openfintech.io/payment_providers/securepaycom/logo.svg?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/securepaycom/logo.svg?w=400&c=v0.59.26#w100
```  

### Icon 
 
![securepaycom](https://static.openfintech.io/payment_providers/securepaycom/icon.svg?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/securepaycom/icon.svg?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"securepaycom",
  "description":null,
  "vendor":"securepaycom",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"securepaycom"
  },
  "name":{
    "en":"SecurePay.com"
  }
}
```  
