
# secupay 
![secupay](https://static.openfintech.io/payment_providers/secupay/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `secupay` 
 
**Vendor:** `secupay` 
 
**Name:** 
 
:	[EN] secupay 
 

## Images 

### Logo 
 
![secupay](https://static.openfintech.io/payment_providers/secupay/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/secupay/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![secupay](https://static.openfintech.io/payment_providers/secupay/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/secupay/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"secupay",
  "description":null,
  "vendor":"secupay",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"secupay"
  },
  "name":{
    "en":"secupay"
  }
}
```  
