
# tpay.com 
![tpaycom](https://static.openfintech.io/payment_providers/tpaycom/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `tpaycom` 
 
**Vendor:** `tpaycom` 
 
**Name:** 
 
:	[EN] tpay.com 
 

## Images 

### Logo 
 
![tpaycom](https://static.openfintech.io/payment_providers/tpaycom/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/tpaycom/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![tpaycom](https://static.openfintech.io/payment_providers/tpaycom/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/tpaycom/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"tpaycom",
  "description":null,
  "vendor":"tpaycom",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"tpaycom"
  },
  "name":{
    "en":"tpay.com"
  }
}
```  
