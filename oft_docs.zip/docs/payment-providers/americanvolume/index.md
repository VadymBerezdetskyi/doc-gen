
# GlobiPay 
![americanvolume](https://static.openfintech.io/payment_providers/americanvolume/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `americanvolume` 
 
**Vendor:** `americanvolume` 
 
**Name:** 
 
:	[EN] GlobiPay 
 

## Images 

### Logo 
 
![americanvolume](https://static.openfintech.io/payment_providers/americanvolume/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/americanvolume/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![americanvolume](https://static.openfintech.io/payment_providers/americanvolume/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/americanvolume/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"americanvolume",
  "description":null,
  "vendor":"americanvolume",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"americanvolume"
  },
  "name":{
    "en":"GlobiPay"
  }
}
```  
