
# Axiar Payments 
![axiarpaymentsolutionslimited](https://static.openfintech.io/payment_providers/axiarpaymentsolutionslimited/logo.svg?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `axiarpaymentsolutionslimited` 
 
**Vendor:** `axiarpaymentsolutionslimited` 
 
**Name:** 
 
:	[EN] Axiar Payments 
 

## Images 

### Logo 
 
![axiarpaymentsolutionslimited](https://static.openfintech.io/payment_providers/axiarpaymentsolutionslimited/logo.svg?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/axiarpaymentsolutionslimited/logo.svg?w=400&c=v0.59.26#w100
```  

### Icon 
 
![axiarpaymentsolutionslimited](https://static.openfintech.io/payment_providers/axiarpaymentsolutionslimited/icon.svg?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/axiarpaymentsolutionslimited/icon.svg?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"axiarpaymentsolutionslimited",
  "description":null,
  "vendor":"axiarpaymentsolutionslimited",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"axiarpaymentsolutionslimited"
  },
  "name":{
    "en":"Axiar Payments"
  }
}
```  
