
# IKoruna 
![ikorunapaymentsystems](https://static.openfintech.io/payment_providers/ikorunapaymentsystems/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `ikorunapaymentsystems` 
 
**Vendor:** `ikorunapaymentsystems` 
 
**Name:** 
 
:	[EN] IKoruna 
 

## Images 

### Logo 
 
![ikorunapaymentsystems](https://static.openfintech.io/payment_providers/ikorunapaymentsystems/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/ikorunapaymentsystems/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![ikorunapaymentsystems](https://static.openfintech.io/payment_providers/ikorunapaymentsystems/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/ikorunapaymentsystems/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"ikorunapaymentsystems",
  "description":null,
  "vendor":"ikorunapaymentsystems",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"ikorunapaymentsystems"
  },
  "name":{
    "en":"IKoruna"
  }
}
```  
