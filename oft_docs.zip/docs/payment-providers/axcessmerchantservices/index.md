
# Axcess Merchant Services 
![axcessmerchantservices](https://static.openfintech.io/payment_providers/axcessmerchantservices/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `axcessmerchantservices` 
 
**Vendor:** `axcessmerchantservices` 
 
**Name:** 
 
:	[EN] Axcess Merchant Services 
 

## Images 

### Logo 
 
![axcessmerchantservices](https://static.openfintech.io/payment_providers/axcessmerchantservices/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/axcessmerchantservices/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![axcessmerchantservices](https://static.openfintech.io/payment_providers/axcessmerchantservices/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/axcessmerchantservices/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"axcessmerchantservices",
  "description":null,
  "vendor":"axcessmerchantservices",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"axcessmerchantservices"
  },
  "name":{
    "en":"Axcess Merchant Services"
  }
}
```  
