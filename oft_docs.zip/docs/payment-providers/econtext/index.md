
# econtext 
![econtext](https://static.openfintech.io/payment_providers/econtext/logo.svg?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `econtext` 
 
**Vendor:** `econtext` 
 
**Name:** 
 
:	[EN] econtext 
 

## Images 

### Logo 
 
![econtext](https://static.openfintech.io/payment_providers/econtext/logo.svg?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/econtext/logo.svg?w=400&c=v0.59.26#w100
```  

### Icon 
 
![econtext](https://static.openfintech.io/payment_providers/econtext/icon.svg?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/econtext/icon.svg?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"econtext",
  "description":null,
  "vendor":"econtext",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"econtext"
  },
  "name":{
    "en":"econtext"
  }
}
```  
