
# BILLPRO.com 
![billpro](https://static.openfintech.io/payment_providers/billpro/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `billpro` 
 
**Vendor:** `billpro` 
 
**Name:** 
 
:	[EN] BILLPRO.com 
 

## Images 

### Logo 
 
![billpro](https://static.openfintech.io/payment_providers/billpro/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/billpro/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![billpro](https://static.openfintech.io/payment_providers/billpro/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/billpro/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"billpro",
  "description":null,
  "vendor":"billpro",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"billpro"
  },
  "name":{
    "en":"BILLPRO.com"
  }
}
```  
