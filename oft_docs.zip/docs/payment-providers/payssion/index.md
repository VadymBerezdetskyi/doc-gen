
# Payssion 
![payssion](https://static.openfintech.io/payment_providers/payssion/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `payssion` 
 
**Vendor:** `payssion` 
 
**Name:** 
 
:	[EN] Payssion 
 

## Images 

### Logo 
 
![payssion](https://static.openfintech.io/payment_providers/payssion/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/payssion/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![payssion](https://static.openfintech.io/payment_providers/payssion/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/payssion/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"payssion",
  "description":null,
  "vendor":"payssion",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"payssion"
  },
  "name":{
    "en":"Payssion"
  }
}
```  
