
# AllCharge.com 
![allchargecom](https://static.openfintech.io/payment_providers/allchargecom/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `allchargecom` 
 
**Vendor:** `allchargecom` 
 
**Name:** 
 
:	[EN] AllCharge.com 
 
**Categories:**`distributing` 
 

## Images 

### Logo 
 
![allchargecom](https://static.openfintech.io/payment_providers/allchargecom/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/allchargecom/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![allchargecom](https://static.openfintech.io/payment_providers/allchargecom/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/allchargecom/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"allchargecom",
  "description":null,
  "vendor":"allchargecom",
  "categories":[
    "distributing"
  ],
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"allchargecom"
  },
  "name":{
    "en":"AllCharge.com"
  }
}
```  
