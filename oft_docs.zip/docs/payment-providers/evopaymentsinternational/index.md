
# EVO Payments International 
![evopaymentsinternational](https://static.openfintech.io/payment_providers/evopaymentsinternational/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `evopaymentsinternational` 
 
**Vendor:** `evopaymentsinternational` 
 
**Name:** 
 
:	[EN] EVO Payments International 
 

## Images 

### Logo 
 
![evopaymentsinternational](https://static.openfintech.io/payment_providers/evopaymentsinternational/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/evopaymentsinternational/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![evopaymentsinternational](https://static.openfintech.io/payment_providers/evopaymentsinternational/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/evopaymentsinternational/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"evopaymentsinternational",
  "description":null,
  "vendor":"evopaymentsinternational",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"evopaymentsinternational"
  },
  "name":{
    "en":"EVO Payments International"
  }
}
```  
