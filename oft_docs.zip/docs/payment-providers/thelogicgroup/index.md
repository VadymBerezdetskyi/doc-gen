
# The Logic Group 
![thelogicgroup](https://static.openfintech.io/payment_providers/thelogicgroup/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `thelogicgroup` 
 
**Vendor:** `thelogicgroup` 
 
**Name:** 
 
:	[EN] The Logic Group 
 

## Images 

### Logo 
 
![thelogicgroup](https://static.openfintech.io/payment_providers/thelogicgroup/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/thelogicgroup/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![thelogicgroup](https://static.openfintech.io/payment_providers/thelogicgroup/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/thelogicgroup/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"thelogicgroup",
  "description":null,
  "vendor":"thelogicgroup",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"thelogicgroup"
  },
  "name":{
    "en":"The Logic Group"
  }
}
```  
