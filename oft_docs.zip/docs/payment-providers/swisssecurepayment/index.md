
# Swiss Secure Payment™ 
![swisssecurepayment](https://static.openfintech.io/payment_providers/swisssecurepayment/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `swisssecurepayment` 
 
**Vendor:** `swisssecurepayment` 
 
**Name:** 
 
:	[EN] Swiss Secure Payment™ 
 

## Images 

### Logo 
 
![swisssecurepayment](https://static.openfintech.io/payment_providers/swisssecurepayment/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/swisssecurepayment/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![swisssecurepayment](https://static.openfintech.io/payment_providers/swisssecurepayment/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/swisssecurepayment/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"swisssecurepayment",
  "description":null,
  "vendor":"swisssecurepayment",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"swisssecurepayment"
  },
  "name":{
    "en":"Swiss Secure Payment\u2122"
  }
}
```  
