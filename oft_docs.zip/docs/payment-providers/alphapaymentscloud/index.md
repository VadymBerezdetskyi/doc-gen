
# Alpha Payments Cloud 
![alphapaymentscloud](https://static.openfintech.io/payment_providers/alphapaymentscloud/logo.svg?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `alphapaymentscloud` 
 
**Vendor:** `alphapaymentscloud` 
 
**Name:** 
 
:	[EN] Alpha Payments Cloud 
 

## Images 

### Logo 
 
![alphapaymentscloud](https://static.openfintech.io/payment_providers/alphapaymentscloud/logo.svg?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/alphapaymentscloud/logo.svg?w=400&c=v0.59.26#w100
```  

### Icon 
 
![alphapaymentscloud](https://static.openfintech.io/payment_providers/alphapaymentscloud/icon.svg?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/alphapaymentscloud/icon.svg?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"alphapaymentscloud",
  "description":null,
  "vendor":"alphapaymentscloud",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"alphapaymentscloud"
  },
  "name":{
    "en":"Alpha Payments Cloud"
  }
}
```  
