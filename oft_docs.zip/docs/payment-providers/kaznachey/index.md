
# Kaznachey 
![kaznachey](https://static.openfintech.io/payment_providers/kaznachey/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `kaznachey` 
 
**Vendor:** `kaznachey` 
 
**Name:** 
 
:	[EN] Kaznachey 
 

## Images 

### Logo 
 
![kaznachey](https://static.openfintech.io/payment_providers/kaznachey/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/kaznachey/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![kaznachey](https://static.openfintech.io/payment_providers/kaznachey/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/kaznachey/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"kaznachey",
  "description":null,
  "vendor":"kaznachey",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"kaznachey"
  },
  "name":{
    "en":"Kaznachey"
  }
}
```  
