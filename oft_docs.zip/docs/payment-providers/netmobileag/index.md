
# net mobile AG 
![netmobileag](https://static.openfintech.io/payment_providers/netmobileag/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `netmobileag` 
 
**Vendor:** `netmobileag` 
 
**Name:** 
 
:	[EN] net mobile AG 
 

## Images 

### Logo 
 
![netmobileag](https://static.openfintech.io/payment_providers/netmobileag/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/netmobileag/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![netmobileag](https://static.openfintech.io/payment_providers/netmobileag/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/netmobileag/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"netmobileag",
  "description":null,
  "vendor":"netmobileag",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"netmobileag"
  },
  "name":{
    "en":"net mobile AG"
  }
}
```  
