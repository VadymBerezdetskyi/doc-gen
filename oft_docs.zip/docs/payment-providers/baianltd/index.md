
# Baian Ltd. 
![baianltd](https://static.openfintech.io/payment_providers/baianltd/logo.png?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `baianltd` 
 
**Vendor:** `baianltd` 
 
**Name:** 
 
:	[EN] Baian Ltd. 
 

## Images 

### Logo 
 
![baianltd](https://static.openfintech.io/payment_providers/baianltd/logo.png?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/baianltd/logo.png?w=400&c=v0.59.26#w100
```  

### Icon 
 
![baianltd](https://static.openfintech.io/payment_providers/baianltd/icon.png?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/baianltd/icon.png?w=278&c=v0.59.26#w100
```  

## JSON Object 

```json
{
  "code":"baianltd",
  "description":null,
  "vendor":"baianltd",
  "categories":null,
  "countries":null,
  "payment_method":null,
  "payout_method":null,
  "metadata":{
    "about_payments_code":"baianltd"
  },
  "name":{
    "en":"Baian Ltd."
  }
}
```  
