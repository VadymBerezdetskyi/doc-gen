
# Enfins 
![enfins](https://static.openfintech.io/payment_providers/enfins/logo.svg?w=400&c=v0.59.26#w100)  

## General 
 
**Code:** `enfins` 
 
**Vendor:** `enfins` 
 
**Name:** 
 
:	[EN] Enfins 
 

## Images 

### Logo 
 
![enfins](https://static.openfintech.io/payment_providers/enfins/logo.svg?w=400&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/enfins/logo.svg?w=400&c=v0.59.26#w100
```  

### Icon 
 
![enfins](https://static.openfintech.io/payment_providers/enfins/icon.svg?w=278&c=v0.59.26#w100)  

```
https://static.openfintech.io/payment_providers/enfins/icon.svg?w=278&c=v0.59.26#w100
```  

## Payment Methods 
 
The list of supported [Payment Methods](#) 

|Code| 
|:---| 
 

## Payout Methods 
 
The list of supported [Payout Methods](#) 

|Icon|Name|Code| 
|:---:|:---:|:---:| 
 

## JSON Object 

```json
{
  "code":"enfins",
  "description":null,
  "vendor":"enfins",
  "categories":null,
  "countries":null,
  "payment_method":[
    
  ],
  "payout_method":[
    
  ],
  "metadata":null,
  "name":{
    "en":"Enfins"
  }
}
```  
